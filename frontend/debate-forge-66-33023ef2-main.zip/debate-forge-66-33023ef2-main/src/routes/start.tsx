import { useState } from 'react'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { motion } from 'framer-motion'
import { Sparkles, RotateCcw, Play, Users, Target } from 'lucide-react'
import { PageHeader } from '@/components/shared/page-header'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

const categories = [
  'Tech Stack',
  'Investment',
  'Hiring',
  'Healthcare',
  'Business Strategy',
  'General',
]

const examples = [
  'Should we migrate our core ledger to a new platform?',
  'Allocate our Series B: growth vs. runway?',
  'Adopt on-prem inference for PHI-sensitive workloads?',
]

export const Route = createFileRoute('/start')({ component: StartDebatePage })

function StartDebatePage() {
  const navigate = useNavigate()
  const [prompt, setPrompt] = useState('')
  const [category, setCategory] = useState('Tech Stack')
  const [numAgents, setNumAgents] = useState(6)
  const [threshold, setThreshold] = useState(80)
  const [mode, setMode] = useState<'Automatic' | 'Manual'>('Automatic')
  const [rounds, setRounds] = useState<'Auto Stop' | 'Fixed Rounds'>('Auto Stop')
  const [fixedRounds, setFixedRounds] = useState(4)

  function reset() {
    setPrompt('')
    setCategory('Tech Stack')
    setNumAgents(6)
    setThreshold(80)
    setMode('Automatic')
    setRounds('Auto Stop')
    setFixedRounds(4)
  }

  return (
    <div className="mx-auto max-w-5xl space-y-8 px-4 py-8 md:px-6 md:py-10">
      <PageHeader
        title="Start a Debate"
        breadcrumb="Start Debate"
        description="Configure a decision, choose your agent panel, and let the platform reason it out."
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="lg:col-span-2"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="size-4 text-primary" />
                Decision prompt
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe the decision you want the AI agents to debate..."
                rows={6}
                className="w-full resize-none rounded-xl border border-input bg-muted/30 p-4 text-sm outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
              />
              <div className="flex flex-wrap gap-2">
                {examples.map((ex) => (
                  <button
                    key={ex}
                    onClick={() => setPrompt(ex)}
                    className="rounded-full border border-border bg-muted/40 px-3 py-1 text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
                  >
                    {ex}
                  </button>
                ))}
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium">
                  Decision category
                </label>
                <div className="flex flex-wrap gap-2">
                  {categories.map((c) => (
                    <button
                      key={c}
                      onClick={() => setCategory(c)}
                      className={`rounded-lg border px-3 py-1.5 text-sm transition-colors ${
                        category === c
                          ? 'border-primary/40 bg-primary/15 text-primary'
                          : 'border-border bg-muted/30 text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid gap-6 sm:grid-cols-2">
                <SliderField
                  label="Number of Agents"
                  icon={<Users className="size-4 text-cyan" />}
                  value={numAgents}
                  min={3}
                  max={10}
                  onChange={setNumAgents}
                  suffix=" agents"
                />
                <SliderField
                  label="Consensus Threshold"
                  icon={<Target className="size-4 text-purple" />}
                  value={threshold}
                  min={50}
                  max={100}
                  onChange={setThreshold}
                  suffix="%"
                />
              </div>

              <div className="grid gap-6 sm:grid-cols-2">
                <ToggleField
                  label="Debate Mode"
                  options={['Automatic', 'Manual']}
                  value={mode}
                  onChange={(v) => setMode(v as 'Automatic' | 'Manual')}
                />
                <ToggleField
                  label="Rounds"
                  options={['Auto Stop', 'Fixed Rounds']}
                  value={rounds}
                  onChange={(v) => setRounds(v as 'Auto Stop' | 'Fixed Rounds')}
                />
              </div>

              {rounds === 'Fixed Rounds' && (
                <SliderField
                  label="Fixed Rounds"
                  value={fixedRounds}
                  min={2}
                  max={8}
                  onChange={setFixedRounds}
                  suffix=" rounds"
                />
              )}

              <div className="flex flex-wrap gap-3 pt-2">
                <Button
                  className="glow-primary"
                  disabled={!prompt.trim()}
                  onClick={() => navigate({ to: '/live' })}
                >
                  <Play className="size-4" />
                  Start Debate
                </Button>
                <Button variant="outline" onClick={reset}>
                  <RotateCcw className="size-4" />
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <Card className="sticky top-20">
            <CardHeader>
              <CardTitle>Configuration summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <SummaryRow label="Category" value={<Badge variant="cyan">{category}</Badge>} />
              <SummaryRow label="Agents" value={`${numAgents}`} />
              <SummaryRow label="Threshold" value={`${threshold}%`} />
              <SummaryRow label="Mode" value={mode} />
              <SummaryRow
                label="Rounds"
                value={rounds === 'Fixed Rounds' ? `${fixedRounds} fixed` : 'Auto stop'}
              />
              <div className="rounded-xl border border-border bg-muted/30 p-3 text-xs text-muted-foreground">
                Estimated runtime ~{Math.round(numAgents * 0.6 + 1)}m. Agents debate
                asynchronously until consensus reaches {threshold}%.
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

function SliderField({
  label,
  icon,
  value,
  min,
  max,
  onChange,
  suffix = '',
}: {
  label: string
  icon?: React.ReactNode
  value: number
  min: number
  max: number
  onChange: (v: number) => void
  suffix?: string
}) {
  const pct = ((value - min) / (max - min)) * 100
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <label className="flex items-center gap-1.5 text-sm font-medium">
          {icon}
          {label}
        </label>
        <span className="font-mono text-sm text-primary">
          {value}
          {suffix}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-2 w-full cursor-pointer appearance-none rounded-full outline-none [&::-webkit-slider-thumb]:size-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary [&::-webkit-slider-thumb]:shadow-[0_0_8px_var(--primary)]"
        style={{
          background: `linear-gradient(to right, var(--primary) ${pct}%, var(--muted) ${pct}%)`,
        }}
      />
    </div>
  )
}

function ToggleField({
  label,
  options,
  value,
  onChange,
}: {
  label: string
  options: string[]
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium">{label}</label>
      <div className="flex rounded-xl border border-border bg-muted/30 p-1">
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onChange(o)}
            className={`flex-1 rounded-lg px-3 py-1.5 text-sm transition-colors ${
              value === o
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  )
}

function SummaryRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-border/60 pb-2">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  )
}
