export type Accent =
  | 'primary'
  | 'cyan'
  | 'purple'
  | 'success'
  | 'warning'
  | 'destructive'

export const accentText: Record<Accent, string> = {
  primary: 'text-primary',
  cyan: 'text-cyan',
  purple: 'text-purple',
  success: 'text-success',
  warning: 'text-warning',
  destructive: 'text-destructive',
}

export const accentBg: Record<Accent, string> = {
  primary: 'bg-primary/15',
  cyan: 'bg-cyan/15',
  purple: 'bg-purple/15',
  success: 'bg-success/15',
  warning: 'bg-warning/15',
  destructive: 'bg-destructive/15',
}

export const accentBorder: Record<Accent, string> = {
  primary: 'border-primary/30',
  cyan: 'border-cyan/30',
  purple: 'border-purple/30',
  success: 'border-success/30',
  warning: 'border-warning/30',
  destructive: 'border-destructive/30',
}

export const accentStroke: Record<Accent, string> = {
  primary: 'var(--primary)',
  cyan: 'var(--cyan)',
  purple: 'var(--purple)',
  success: 'var(--success)',
  warning: 'var(--warning)',
  destructive: 'var(--destructive)',
}
