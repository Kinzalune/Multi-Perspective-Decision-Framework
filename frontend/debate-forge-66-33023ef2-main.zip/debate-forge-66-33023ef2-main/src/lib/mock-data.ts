export type AgentStatus = 'thinking' | 'responding' | 'waiting' | 'completed'

export type Agent = {
  id: string
  name: string
  role: string
  accent: 'primary' | 'cyan' | 'purple' | 'success' | 'warning' | 'destructive'
  status: AgentStatus
  confidence: number
  stance: string
  latestArgument: string
}

export const agents: Agent[] = [
  {
    id: 'risk',
    name: 'Risk Analyst',
    role: 'Downside & Compliance',
    accent: 'destructive',
    status: 'completed',
    confidence: 82,
    stance: 'Cautiously against',
    latestArgument:
      'Migrating the core ledger introduces regulatory exposure. We should stage rollout behind feature flags with a rollback SLA under 5 minutes.',
  },
  {
    id: 'optimist',
    name: 'Optimist',
    role: 'Growth & Upside',
    accent: 'success',
    status: 'responding',
    confidence: 91,
    stance: 'Strongly for',
    latestArgument:
      'The upside is a 3x developer velocity gain within two quarters. Early adopters report faster iteration and lower incident rates.',
  },
  {
    id: 'cost',
    name: 'Cost Expert',
    role: 'Budget & TCO',
    accent: 'warning',
    status: 'thinking',
    confidence: 74,
    stance: 'Neutral',
    latestArgument:
      'Total cost of ownership drops 18% after year one, but migration labor front-loads spend. Break-even lands around month 9.',
  },
  {
    id: 'security',
    name: 'Security Expert',
    role: 'Threat & Trust',
    accent: 'cyan',
    status: 'waiting',
    confidence: 88,
    stance: 'Conditionally for',
    latestArgument:
      'Zero-trust posture is achievable if we enforce short-lived credentials and per-query scoping. Threat surface is manageable.',
  },
  {
    id: 'market',
    name: 'Market Analyst',
    role: 'Competitive Landscape',
    accent: 'purple',
    status: 'waiting',
    confidence: 79,
    stance: 'For',
    latestArgument:
      'Competitors have already shipped comparable capabilities. Delaying risks a perceived innovation gap with enterprise buyers.',
  },
  {
    id: 'judge',
    name: 'Judge Agent',
    role: 'Final Arbiter',
    accent: 'primary',
    status: 'waiting',
    confidence: 87,
    stance: 'Deliberating',
    latestArgument:
      'Weighing convergence across agents. Consensus trending upward with security guardrails as the deciding factor.',
  },
]

export type DebateMessage = {
  id: string
  agentId: string
  round: number
  timestamp: string
  text: string
}

export const debateTimeline: DebateMessage[] = [
  {
    id: 'm1',
    agentId: 'optimist',
    round: 1,
    timestamp: '10:02:14',
    text: 'Opening position: the migration unlocks compounding velocity gains that outpace short-term costs.',
  },
  {
    id: 'm2',
    agentId: 'risk',
    round: 1,
    timestamp: '10:02:31',
    text: 'Counterpoint: the regulated ledger cannot tolerate downtime. We need a staged rollback strategy first.',
  },
  {
    id: 'm3',
    agentId: 'cost',
    round: 1,
    timestamp: '10:02:52',
    text: 'Financially, front-loaded labor is the main concern. TCO improves but only after month 9.',
  },
  {
    id: 'm4',
    agentId: 'security',
    round: 2,
    timestamp: '10:03:20',
    text: 'Security is tractable with short-lived credentials and per-query scoping. I can support with guardrails.',
  },
  {
    id: 'm5',
    agentId: 'market',
    round: 2,
    timestamp: '10:03:44',
    text: 'Market timing favors action. Competitors already ship this; hesitation signals stagnation.',
  },
  {
    id: 'm6',
    agentId: 'risk',
    round: 3,
    timestamp: '10:04:10',
    text: 'Conceding partially: with a 5-minute rollback SLA and feature flags, downside is contained.',
  },
]

export const consensusEvolution = [
  { round: 1, consensus: 41 },
  { round: 2, consensus: 58 },
  { round: 3, consensus: 69 },
  { round: 4, consensus: 78 },
  { round: 5, consensus: 87 },
]

export type EventLog = {
  id: string
  time: string
  level: 'info' | 'success' | 'warning' | 'agent'
  message: string
}

export const eventLog: EventLog[] = [
  { id: 'e1', time: '10:02:00', level: 'info', message: 'Debate started — 6 agents initialized' },
  { id: 'e2', time: '10:02:31', level: 'agent', message: 'Risk Analyst submitted argument (Round 1)' },
  { id: 'e3', time: '10:02:52', level: 'agent', message: 'Cost Expert submitted argument (Round 1)' },
  { id: 'e4', time: '10:03:05', level: 'success', message: 'Round 1 completed — consensus 41%' },
  { id: 'e5', time: '10:03:44', level: 'agent', message: 'Market Analyst submitted argument (Round 2)' },
  { id: 'e6', time: '10:04:12', level: 'warning', message: 'Consensus updated — arguments converging' },
  { id: 'e7', time: '10:04:40', level: 'info', message: 'Judge Agent activated' },
]

export const judgeRecommendation = {
  recommendation: 'Proceed with a staged migration behind feature flags',
  confidence: 87,
  summary:
    'The panel converged on proceeding with the platform migration, gated by security guardrails and a fast rollback SLA. The velocity and market-timing benefits outweigh contained, well-mitigated risks.',
  pros: [
    '3x developer velocity within two quarters',
    '18% lower total cost of ownership after year one',
    'Closes the competitive innovation gap',
  ],
  cons: [
    'Front-loaded migration labor and spend',
    'Break-even not reached until month 9',
    'Requires disciplined rollout governance',
  ],
  risks: [
    'Regulatory exposure on the core ledger',
    'Short-term incident risk during cutover',
    'Team ramp-up on the new platform',
  ],
  verdict: 'GO — conditional on rollback SLA under 5 minutes and per-query credential scoping.',
}

export type DebateHistory = {
  id: string
  title: string
  date: string
  category: string
  agents: number
  consensus: number
  status: 'Consensus' | 'Stagnated' | 'Running'
  decision: string
}

export const debateHistory: DebateHistory[] = [
  {
    id: 'd1',
    title: 'Migrate core ledger to new platform',
    date: '2026-07-15',
    category: 'Tech Stack',
    agents: 6,
    consensus: 87,
    status: 'Consensus',
    decision: 'Proceed with staged migration',
  },
  {
    id: 'd2',
    title: 'Series B allocation strategy',
    date: '2026-07-12',
    category: 'Investment',
    agents: 5,
    consensus: 72,
    status: 'Consensus',
    decision: 'Split 60/40 growth vs. runway',
  },
  {
    id: 'd3',
    title: 'Senior hire: platform vs. product',
    date: '2026-07-09',
    category: 'Hiring',
    agents: 4,
    consensus: 54,
    status: 'Stagnated',
    decision: 'No clear consensus — revisit',
  },
  {
    id: 'd4',
    title: 'Adopt on-prem inference for PHI data',
    date: '2026-07-05',
    category: 'Healthcare',
    agents: 7,
    consensus: 91,
    status: 'Consensus',
    decision: 'Adopt hybrid on-prem inference',
  },
  {
    id: 'd5',
    title: 'Expand into EMEA market',
    date: '2026-07-01',
    category: 'Business Strategy',
    agents: 6,
    consensus: 68,
    status: 'Consensus',
    decision: 'Phase 1 pilot in Germany',
  },
  {
    id: 'd6',
    title: 'Rewrite billing service',
    date: '2026-06-28',
    category: 'Tech Stack',
    agents: 5,
    consensus: 63,
    status: 'Consensus',
    decision: 'Incremental strangler-fig rewrite',
  },
]

export const kpis = [
  { label: 'Total Debates', value: '1,284', delta: '+12.4%', trend: 'up' as const },
  { label: 'Avg Consensus Time', value: '3m 42s', delta: '-8.1%', trend: 'down' as const },
  { label: 'Avg Confidence', value: '86.3%', delta: '+2.2%', trend: 'up' as const },
  { label: 'Avg Debate Rounds', value: '4.6', delta: '+0.3', trend: 'up' as const },
  { label: 'Consensus Success', value: '92.7%', delta: '+1.9%', trend: 'up' as const },
  { label: 'Active Agents', value: '6', delta: 'live', trend: 'up' as const },
]

export const consensusTrend = [
  { month: 'Feb', consensus: 74 },
  { month: 'Mar', consensus: 78 },
  { month: 'Apr', consensus: 81 },
  { month: 'May', consensus: 83 },
  { month: 'Jun', consensus: 85 },
  { month: 'Jul', consensus: 89 },
]

export const agentParticipation = [
  { agent: 'Risk', debates: 980 },
  { agent: 'Optimist', debates: 1120 },
  { agent: 'Cost', debates: 870 },
  { agent: 'Security', debates: 760 },
  { agent: 'Market', debates: 690 },
  { agent: 'Judge', debates: 1284 },
]

export const debatesPerCategory = [
  { category: 'Tech Stack', value: 420, fill: 'var(--chart-1)' },
  { category: 'Investment', value: 260, fill: 'var(--chart-2)' },
  { category: 'Hiring', value: 190, fill: 'var(--chart-3)' },
  { category: 'Healthcare', value: 150, fill: 'var(--chart-4)' },
  { category: 'Strategy', value: 264, fill: 'var(--chart-5)' },
]

export const confidenceDistribution = [
  { bucket: '50-60', count: 42 },
  { bucket: '60-70', count: 118 },
  { bucket: '70-80', count: 296 },
  { bucket: '80-90', count: 512 },
  { bucket: '90-100', count: 316 },
]

export const responseTime = [
  { round: 'R1', ms: 1200 },
  { round: 'R2', ms: 980 },
  { round: 'R3', ms: 1100 },
  { round: 'R4', ms: 860 },
  { round: 'R5', ms: 740 },
]

export const transcript = [
  {
    round: 1,
    entries: [
      { agentId: 'optimist', text: 'Opening: migration unlocks compounding velocity gains.' },
      { agentId: 'risk', text: 'Counter: regulated ledger cannot tolerate downtime.' },
      { agentId: 'cost', text: 'Front-loaded labor is the main financial concern.' },
    ],
  },
  {
    round: 2,
    entries: [
      { agentId: 'security', text: 'Security is tractable with short-lived credentials.' },
      { agentId: 'market', text: 'Market timing favors decisive action now.' },
    ],
  },
  {
    round: 3,
    entries: [
      { agentId: 'risk', text: 'Conceding: with rollback SLA, downside is contained.' },
      { agentId: 'optimist', text: 'Agreed on guardrails — velocity case still holds.' },
    ],
  },
  {
    round: 4,
    entries: [
      { agentId: 'judge', text: 'Synthesizing convergence into a final recommendation.' },
    ],
  },
]
